package com.dev.biostoreapi.model.enums;

public enum MainCategoryNameEnum {

    BIO, HANDMADE
}
