package com.dev.biostoreapi.model.enums;

public enum SubCategoryNameEnum {

    COSMETICS,
    HANDBAGS,
    ACCESSORIES,
    CLOTHES,
    FRUITS,
    VEGETABLES,
    HONEY,
    OTHERS
}
