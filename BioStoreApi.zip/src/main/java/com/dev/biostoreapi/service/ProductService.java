package com.dev.biostoreapi.service;


import com.dev.biostoreapi.model.entity.ProductEntity;

import java.util.List;

public interface ProductService {

    List<ProductEntity> getAllProducts();

}
